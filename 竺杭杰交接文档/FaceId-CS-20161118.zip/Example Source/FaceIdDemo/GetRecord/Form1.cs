﻿/* ----------------------------------------------------------
 * 文件名称：Form1.cs
 * 作者：秦建辉
 * 
 * 微信：splashcn
 * 
 * 博客：http://www.firstsolver.com/wordpress/
 * 
 * 开发环境：
 *      Visual Studio V2013
 *      .NET Framework 4.0
 *      
 * 版本历史：
 *      V1.2	2016年07月14日
 *              因SDK改进更新代码
 *               
 *      V1.1    2014年11月04日
 *              完善考勤记录提取正则表达式，使之能完整获取带照片的考勤记录
 * 
 *      V1.0	2014年09月13日
 *              人脸通SDK演示：获取考勤记录
------------------------------------------------------------ */
using Com.FirstSolver.Splash;
using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Splash
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// 设备通信字符集为简体中文
        /// </summary>
        private const int DeviceCodePage = 936;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxAnswer.Clear();
        }

        private void buttonExport_Click(object sender, EventArgs e)
        {
            try
            {
                using(FaceId Client = new FaceId(textBoxDeviceIP.Text, Convert.ToInt32(textBoxDevicePort.Text)))
                {
                    Client.SecretKey = textBoxSecretKey.Text.Trim();

                    // 获取截止到当前的所有考勤记录
                    string Answer;
                    FaceId_ErrorCode ErrorCode = Client.Execute("GetRecord(end_time=\"" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\")", out Answer, DeviceCodePage);
                    if(ErrorCode == FaceId_ErrorCode.Success)
                    {
                        // 包含二个子表达式的正则表达式
                        string Pattern = "\\b(time=.+\r\n(?:photo=\"[^\"]+\")*)";
                        MatchCollection matches = Regex.Matches(Answer, Pattern);   // 获取所有匹配项
                        if (matches != null)
                        {
                            foreach (Match match in matches)
                            {
                                textBoxAnswer.AppendText(match.Groups[1].Value + "\r\n");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("错误代码：" + ErrorCode.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBoxAnswer.MaxLength = 0;
        }
    }
}
