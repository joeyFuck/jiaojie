﻿/* ----------------------------------------------------------
 * 文件名称：Form1.cs
 * 作者：秦建辉
 * 
 * 微信：splashcn
 * 
 * 博客：http://www.firstsolver.com/wordpress/
 * 
 * 开发环境：
 *      Visual Studio V2013
 *      .NET Framework 4.0
 *      
 * 版本历史： 
 *      V1.1	2016年07月14日
 *              因SDK改进更新代码
 *              
 *      V1.0	2014年09月12日
 *              人脸通SDK演示：人脸模板导入导出
------------------------------------------------------------ */
using Com.FirstSolver.Splash;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Splash
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// 设备通信字符集编码为简体中文GB2312
        /// </summary>
        public const int DeviceCodePage = 936;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExport_Click(object sender, EventArgs e)
        {
            // 检测导出文件路径
            string SaveFileName;
            try
            {
                SaveFileName = Path.GetFullPath(textBoxExportFileName.Text);
            }
            catch
            {
                MessageBox.Show("不正确的导出文件路径！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 连接到设备
            try
            {
                using (FaceId Client = new FaceId(textBoxExportIP.Text, Convert.ToInt32(textBoxExportPort.Text)))
                {
                    Client.SecretKey = textBoxSecretKeyExport.Text.Trim();

                    // 获取员工工号集合
                    string Answer;
                    FaceId_ErrorCode ErrorCode = Client.Execute("GetEmployeeID()", out Answer, DeviceCodePage);
                    if (ErrorCode == FaceId_ErrorCode.Success)
                    {   // 获取所有数据项
                        FaceId_Item[] ItemCollection = FaceId_Item.GetAllItems(Answer);
                        if (ItemCollection != null)
                        {   // 成功导出的人员数
                            int SaveIdCount = 0;

                            // 基于LINQ查询提取员工工号集合
                            string[] EmployeeIdCollection = (from item in ItemCollection where (item.Name.Equals("id")) select item.Value).ToArray();
                            using (StreamWriter sw = new StreamWriter(SaveFileName, false, Encoding.UTF8))
                            {
                                foreach (string EmployeeId in EmployeeIdCollection)
                                {
                                    ErrorCode = Client.Execute("GetEmployee(id=\"" + EmployeeId + "\")", out Answer, DeviceCodePage);
                                    if (ErrorCode == FaceId_ErrorCode.Success)
                                    {
                                        sw.WriteLine(Answer);
                                        SaveIdCount++;
                                    }
                                }
                            }

                            string Content = "成功导出人员" + SaveIdCount + "/" + EmployeeIdCollection.Length + "！";
                            MessageBox.Show(Content, "信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void buttonImport_Click(object sender, EventArgs e)
        {
            // 检测导出文件路径
            string OpenFileName;
            try
            {
                OpenFileName = Path.GetFullPath(textBoxImportFileName.Text);
            }
            catch
            {
                MessageBox.Show("不正确的导入文件路径！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 连接到设备
            try
            {
                using (FaceId Client = new FaceId(textBoxImportIP.Text, Convert.ToInt32(textBoxImportPort.Text)))
                {
                    Client.SecretKey = textBoxSecretKeyImport.Text.Trim();

                    // 读取文件内容
                    string Source = null;
                    using (StreamReader sr = new StreamReader(OpenFileName, Encoding.UTF8))
                    {
                        Source = sr.ReadToEnd();
                    }

                    if (!string.IsNullOrEmpty(Source))
                    {
                        // 创建列表
                        List<FaceId_Item> ItemList = new List<FaceId_Item>();
                        string[] EmployeeIdCollection = null;

                        // 包含二个子表达式的正则表达式
                        string Pattern = "Return[(]result=\"success\"\\s+(id=\"([a-z|A-Z|0-9]+)\"\\s+[^)]+)[)]";
                        MatchCollection matches = Regex.Matches(Source, Pattern);   // 获取所有匹配项
                        if (matches != null)
                        {
                            foreach (Match match in matches)
                            {
                                ItemList.Add(new FaceId_Item(match.Groups[2].Value, match.Groups[1].Value));
                            }
                        }

                        // 获取员工工号集合                
                        string Answer;
                        FaceId_ErrorCode ErrorCode = Client.Execute("GetEmployeeID()", out Answer, DeviceCodePage);
                        if (ErrorCode == FaceId_ErrorCode.Success)
                        {   // 获取所有数据项
                            FaceId_Item[] ItemCollection = FaceId_Item.GetAllItems(Answer);
                            if (ItemCollection != null)
                            {   // 基于LINQ查询提取员工工号集合
                                EmployeeIdCollection = (from item in ItemCollection where (item.Name.Equals("id")) select item.Value).ToArray();
                            }
                        }

                        // 导入人脸数据
                        int SkipCount = 0;
                        int SaveCount = 0;
                        foreach (FaceId_Item Item in ItemList)
                        {
                            if (!checkBoxOverlap.Checked)
                            {
                                if ((EmployeeIdCollection != null) && EmployeeIdCollection.Contains(Item.Name))
                                {
                                    SkipCount++;
                                    continue;
                                }
                            }

                            ErrorCode = Client.Execute("SetEmployee(" + Item.Value + ")", out Answer, DeviceCodePage);
                            if (ErrorCode == FaceId_ErrorCode.Success)
                            {
                                SaveCount++;
                            }
                        }

                        string Content = "成功/跳过/总计人员=" + SaveCount + "/" + SkipCount + "/" + ItemList.Count + "！";
                        MessageBox.Show(Content, "信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 选择导入文件名
        private void buttonImportDialog_Click(object sender, EventArgs e)
        {
            OpenFileDialog OpenDialog = new OpenFileDialog();
            OpenDialog.InitialDirectory = System.AppDomain.CurrentDomain.BaseDirectory;
            OpenDialog.Multiselect = false;
            OpenDialog.RestoreDirectory = true;
            OpenDialog.ReadOnlyChecked = true;
            OpenDialog.Filter = "dat files (*.dat)|*.dat|All files (*.*)|*.*";
            if (OpenDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                textBoxImportFileName.Text = OpenDialog.FileName;
            }
        }

        // 设置导出文件名
        private void buttonExportDialog_Click(object sender, EventArgs e)
        {
            SaveFileDialog SaveDialog = new SaveFileDialog();
            SaveDialog.InitialDirectory = System.AppDomain.CurrentDomain.BaseDirectory;
            SaveDialog.RestoreDirectory = true;
            SaveDialog.Filter = "dat files (*.dat)|*.dat|All files (*.*)|*.*";
            if (SaveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                textBoxExportFileName.Text = SaveDialog.FileName;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 将应用程序路径设置为当前路径
            Directory.SetCurrentDirectory(System.AppDomain.CurrentDomain.BaseDirectory);            
        }
    }
}
