﻿/* ----------------------------------------------------------
 * 文件名称：Form1.cs
 * 作者：秦建辉
 * 
 * 微信：splashcn
 * 
 * 博客：http://www.firstsolver.com/wordpress/
 * 
 * 开发环境：
 *      Visual Studio V2013
 *      .NET Framework 4.0
 *      
 * 版本历史： 
 *      V1.1	2016年07月14日
 *              因SDK改进更新代码
 *              
 *      V1.0	2014年09月12日
 *              人脸通SDK演示：执行设备命令
------------------------------------------------------------ */
using Com.FirstSolver.Splash;
using System;
using System.Windows.Forms;

namespace Splash
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// 设备通信字符集为简体中文
        /// </summary>
        private const int DeviceCodePage = 936;

        public Form1()
        {
            InitializeComponent();

            // 设置允许命令字符串的最大长度
            textBoxCommand.MaxLength = int.MaxValue;
            textBoxAnswer.MaxLength = int.MaxValue;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxAnswer.Clear();
        }

        private void buttonExecuteCommand_Click(object sender, EventArgs e)
        {
            try
            {
                using(FaceId Client = new FaceId(textBoxDeviceIP.Text, Convert.ToInt32(textBoxDevicePort.Text)))
                { 
                    // 设置通信密钥
                    Client.SecretKey = textBoxSecretKey.Text.Trim();

                    string Answer;
                    FaceId_ErrorCode ErrorCode = Client.Execute(textBoxCommand.Text, out Answer, DeviceCodePage);
                    if(ErrorCode == FaceId_ErrorCode.Success)
                    {
                        textBoxAnswer.Text = Answer;
                    }
                    else
                    {
                        MessageBox.Show("错误代码：" + ErrorCode.ToString(), "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBoxCommand.MaxLength = 0;
            textBoxAnswer.MaxLength = 0;
        }
    }
}
