﻿namespace Splash
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxSecretKeyExport = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonExportDialog = new System.Windows.Forms.Button();
            this.textBoxExportFileName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxExportPort = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxExportIP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonExport = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxSecretKeyImport = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.checkBoxOverlap = new System.Windows.Forms.CheckBox();
            this.buttonImportDialog = new System.Windows.Forms.Button();
            this.textBoxImportFileName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxImportPort = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxImportIP = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonImport = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(352, 351);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.buttonExport);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(344, 325);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "导出人脸模板";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxSecretKeyExport);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.buttonExportDialog);
            this.groupBox1.Controls.Add(this.textBoxExportFileName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBoxExportPort);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxExportIP);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(15, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(311, 234);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设置";
            // 
            // textBoxSecretKeyExport
            // 
            this.textBoxSecretKeyExport.Location = new System.Drawing.Point(80, 96);
            this.textBoxSecretKeyExport.Name = "textBoxSecretKeyExport";
            this.textBoxSecretKeyExport.Size = new System.Drawing.Size(175, 21);
            this.textBoxSecretKeyExport.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 21;
            this.label7.Text = "通信密码";
            // 
            // buttonExportDialog
            // 
            this.buttonExportDialog.Location = new System.Drawing.Point(274, 192);
            this.buttonExportDialog.Name = "buttonExportDialog";
            this.buttonExportDialog.Size = new System.Drawing.Size(27, 23);
            this.buttonExportDialog.TabIndex = 20;
            this.buttonExportDialog.Text = "…";
            this.buttonExportDialog.UseVisualStyleBackColor = true;
            this.buttonExportDialog.Click += new System.EventHandler(this.buttonExportDialog_Click);
            // 
            // textBoxExportFileName
            // 
            this.textBoxExportFileName.Location = new System.Drawing.Point(20, 193);
            this.textBoxExportFileName.Name = "textBoxExportFileName";
            this.textBoxExportFileName.Size = new System.Drawing.Size(249, 21);
            this.textBoxExportFileName.TabIndex = 19;
            this.textBoxExportFileName.Text = "Employees.dat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "导出文件路径：";
            // 
            // textBoxExportPort
            // 
            this.textBoxExportPort.Location = new System.Drawing.Point(80, 57);
            this.textBoxExportPort.Name = "textBoxExportPort";
            this.textBoxExportPort.ReadOnly = true;
            this.textBoxExportPort.Size = new System.Drawing.Size(175, 21);
            this.textBoxExportPort.TabIndex = 17;
            this.textBoxExportPort.Text = "9922";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 16;
            this.label2.Text = "设备端口";
            // 
            // textBoxExportIP
            // 
            this.textBoxExportIP.Location = new System.Drawing.Point(80, 18);
            this.textBoxExportIP.Name = "textBoxExportIP";
            this.textBoxExportIP.Size = new System.Drawing.Size(175, 21);
            this.textBoxExportIP.TabIndex = 15;
            this.textBoxExportIP.Text = "192.168.1.19";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "设备地址";
            // 
            // buttonExport
            // 
            this.buttonExport.Location = new System.Drawing.Point(123, 264);
            this.buttonExport.Name = "buttonExport";
            this.buttonExport.Size = new System.Drawing.Size(64, 46);
            this.buttonExport.TabIndex = 4;
            this.buttonExport.Text = "导出";
            this.buttonExport.UseVisualStyleBackColor = true;
            this.buttonExport.Click += new System.EventHandler(this.buttonExport_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.buttonImport);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(344, 325);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "导入人脸模板";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxSecretKeyImport);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.checkBoxOverlap);
            this.groupBox2.Controls.Add(this.buttonImportDialog);
            this.groupBox2.Controls.Add(this.textBoxImportFileName);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBoxImportPort);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.textBoxImportIP);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(16, 16);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(311, 225);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "设置";
            // 
            // textBoxSecretKeyImport
            // 
            this.textBoxSecretKeyImport.Location = new System.Drawing.Point(80, 90);
            this.textBoxSecretKeyImport.Name = "textBoxSecretKeyImport";
            this.textBoxSecretKeyImport.Size = new System.Drawing.Size(175, 21);
            this.textBoxSecretKeyImport.TabIndex = 24;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 23;
            this.label8.Text = "通信密码";
            // 
            // checkBoxOverlap
            // 
            this.checkBoxOverlap.AutoSize = true;
            this.checkBoxOverlap.Location = new System.Drawing.Point(176, 160);
            this.checkBoxOverlap.Margin = new System.Windows.Forms.Padding(2);
            this.checkBoxOverlap.Name = "checkBoxOverlap";
            this.checkBoxOverlap.Size = new System.Drawing.Size(96, 16);
            this.checkBoxOverlap.TabIndex = 21;
            this.checkBoxOverlap.Text = "覆盖已有模板";
            this.checkBoxOverlap.UseVisualStyleBackColor = true;
            // 
            // buttonImportDialog
            // 
            this.buttonImportDialog.Location = new System.Drawing.Point(274, 184);
            this.buttonImportDialog.Name = "buttonImportDialog";
            this.buttonImportDialog.Size = new System.Drawing.Size(27, 23);
            this.buttonImportDialog.TabIndex = 20;
            this.buttonImportDialog.Text = "…";
            this.buttonImportDialog.UseVisualStyleBackColor = true;
            this.buttonImportDialog.Click += new System.EventHandler(this.buttonImportDialog_Click);
            // 
            // textBoxImportFileName
            // 
            this.textBoxImportFileName.Location = new System.Drawing.Point(20, 185);
            this.textBoxImportFileName.Name = "textBoxImportFileName";
            this.textBoxImportFileName.Size = new System.Drawing.Size(249, 21);
            this.textBoxImportFileName.TabIndex = 19;
            this.textBoxImportFileName.Text = "Employees.dat";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 18;
            this.label4.Text = "导入文件路径：";
            // 
            // textBoxImportPort
            // 
            this.textBoxImportPort.Location = new System.Drawing.Point(80, 54);
            this.textBoxImportPort.Name = "textBoxImportPort";
            this.textBoxImportPort.ReadOnly = true;
            this.textBoxImportPort.Size = new System.Drawing.Size(175, 21);
            this.textBoxImportPort.TabIndex = 17;
            this.textBoxImportPort.Text = "9922";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 16;
            this.label5.Text = "设备端口";
            // 
            // textBoxImportIP
            // 
            this.textBoxImportIP.Location = new System.Drawing.Point(80, 18);
            this.textBoxImportIP.Name = "textBoxImportIP";
            this.textBoxImportIP.Size = new System.Drawing.Size(175, 21);
            this.textBoxImportIP.TabIndex = 15;
            this.textBoxImportIP.Text = "192.168.1.20";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 14;
            this.label6.Text = "设备地址";
            // 
            // buttonImport
            // 
            this.buttonImport.Location = new System.Drawing.Point(136, 259);
            this.buttonImport.Name = "buttonImport";
            this.buttonImport.Size = new System.Drawing.Size(64, 46);
            this.buttonImport.TabIndex = 15;
            this.buttonImport.Text = "导入";
            this.buttonImport.UseVisualStyleBackColor = true;
            this.buttonImport.Click += new System.EventHandler(this.buttonImport_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 371);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "人脸模板导入导出";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonExportDialog;
        private System.Windows.Forms.TextBox textBoxExportFileName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxExportPort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxExportIP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonExport;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBoxOverlap;
        private System.Windows.Forms.Button buttonImportDialog;
        private System.Windows.Forms.TextBox textBoxImportFileName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxImportPort;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxImportIP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonImport;
        private System.Windows.Forms.TextBox textBoxSecretKeyExport;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxSecretKeyImport;
        private System.Windows.Forms.Label label8;
    }
}

